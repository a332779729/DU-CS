# Complete the sorting algorithms below.
# Since Python uses pass-by-reference for function calls
# with objects, you should sort the copy of the input
# list instead of the input list itself.

# Question 1: Bubble Sort
def bubbleSort(inputLst):
    lst = inputLst.copy()
    n = len(lst)

    ### YOUR CODE HERE ###

    return lst

# Question 2: Cocktail Shaker Sort
def cocktailShakerSort(inputLst):
    lst = inputLst.copy()
    n = len(lst)

    ### YOUR CODE HERE ###

    return lst

# Question 3: Comb Sort
def combSort(inputLst):
    lst = inputLst.copy()
    n = len(lst)

    ### YOUR CODE HERE ###
    
    return lst

# Question 4: Gnome Sort
def gnomeSort(inputLst):
    lst = inputLst.copy()
    n = len(lst)

    ### YOUR CODE HERE ###
    
    return lst
