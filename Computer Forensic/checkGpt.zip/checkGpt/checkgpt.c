// checkgtp.c
// gcc -o checkgpt checkgtp.c
// ./checkgpt target_disk_path

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>	// open()
#include <unistd.h>	// read()
#include <stdio.h>	// printf()
#include <stdint.h>	// uint16_t
#include <string.h>	// strncmp()
#include <endian.h>	// htobe16()

#define LBA_SIZE 512
#define DEFAULT_PARTITION_ENTRY_SIZE 128

uint32_t g_num_partition_entries;
uint32_t g_size_each_partition_entry;

struct gpt_header_info {
	char signature[8];
	char revision[4];
	uint32_t header_size;
	uint32_t crc32_of_header;
	uint32_t reserved_zero;
	uint64_t current_lba; // location of this header copy
	uint64_t backup_lba;
	uint64_t first_usable_lba_for_partition;
	uint64_t last_usable_lba;
	char disk_guid[16];
	uint64_t start_lba_part_entries;
	uint32_t num_partition_entries;
	uint32_t size_single_partition_entry;
};

union gpt_header {
	char padding[LBA_SIZE];
	struct gpt_header_info info;
};

int print_gpt_header_info(const int fd, off_t offset)
{
	char buf[LBA_SIZE];
	int size_readed;
	union gpt_header *header;

	// Reading GPT header information from second LBA.
	size_readed = pread(fd, buf, LBA_SIZE, offset);
	if (size_readed != LBA_SIZE) {
		printf("Error: read() failed!\n");
		return 2;
	}
	
	// Verifying GPT signature.
	header = (union gpt_header *)buf;
	if (strncmp((*header).info.signature, "EFI PART", 8) != 0) {
		printf("Error: Bad signagure!\n");
		return 3;
	}
	
	// Printing GPT header information.
	printf("Disk GUID: %X\n", (*header).info.disk_guid);
	printf("LBA address of first usable LBA for user partitions: %lu (0x%X)\n",\
		(*header).info.first_usable_lba_for_partition);
	printf("LBA address of last usable LBA for user partitions: %lu (0x%X)\n",\
		(*header).info.last_usable_lba);
	printf("LBA address of starting LBA where partition entries begin: %lu (0x%X)\n",\
		(*header).info.start_lba_part_entries);
	g_num_partition_entries = (*header).info.num_partition_entries;
	g_size_each_partition_entry = (*header).info.size_single_partition_entry;
	printf("Number of partition entries: %u (0x%X)\n",\
		g_num_partition_entries); 
	printf("Size of each partition: %u (0x%X)\n",\
		g_size_each_partition_entry);

	return 0;
}

struct partition_entry_info {
	uint16_t partition_type_guid[8];
	uint16_t unique_partition_guid[8];
	uint64_t first_lba;
	uint64_t last_lba;
	uint64_t attribute_flags;
	char partition_name[72]; // 36 UTF-16LE code units.
};

union partition_entry {
	char padding[DEFAULT_PARTITION_ENTRY_SIZE];
	struct partition_entry_info info;
};

int print_part_type_guid(const uint16_t *type_guid)
{
	printf("Partition type GUID: %04X%04X-%04X-%04X-%04X-%04X%04X%04X\n",\
		type_guid[1], type_guid[0],
		type_guid[2], type_guid[3],
		htobe16(type_guid[4]),
		htobe16(type_guid[5]),
		htobe16(type_guid[6]),
		htobe16(type_guid[7]));
	return 0;
}

int print_part_name(const char *part_name)
{
	// Only decoding English partition names.
	// For characters in ASCII, only first 8 bits in UTF-16 are used.
	int i = 0;
	printf("Partition name: ");
	while (i < 36) {
		if (part_name[i * 2] != '\0') {
			printf("%c", part_name[i * 2]);
			i++;
		} else {
			break;
		}
	}
	printf("\n");
	
	return 0;
}

int print_partition_info(const int fd, off_t offset)
{
	int loop;
	char *buf[LBA_SIZE];
	int size_readed;
	union partition_entry *entry;

	for (loop = 0; loop < g_num_partition_entries; loop++) {
		// Reading information of partitions.
		size_readed = pread(fd, buf, g_size_each_partition_entry, offset);
		if (size_readed != g_size_each_partition_entry) {
			printf("Error: read() failed!\n");
			return 2;
		}
		offset += g_size_each_partition_entry;

		entry = (union partition_entry *)buf;

		// Verifying partition information.
		if ((*entry).info.partition_type_guid[0] == 0) {
			continue;
		}
		
		// Printing partition information.
		printf("=====Partition %d=====\n", loop);
		print_part_type_guid((*entry).info.partition_type_guid);
		printf("First LBA address of the partition: %u (0x%X)\n",\
			(*entry).info.first_lba, (*entry).info.first_lba);
		printf("Last LBA address of the partition: %u (0x%X)\n",\
			(*entry).info.last_lba, (*entry).info.last_lba);
		printf("Attribute flags: %016X\n",\
			(*entry).info.attribute_flags);
		print_part_name((*entry).info.partition_name);
	}

	return 0;
}

int main(int argc, char *argv[])
{
	char *target_disk_path;
	int fd;
	off_t offset;
	int rc;

	if (argc > 1) {
		target_disk_path = argv[1];
	} else {
		target_disk_path = "./disk.img";
	}

	fd = open(target_disk_path, O_RDONLY);
	if (fd < 0) {
		printf("Error: open() failed!\n");
		return 1;
	}

	// Skiping MBR table on the first LBA.
	offset = LBA_SIZE;
	rc = print_gpt_header_info(fd, offset);
	if (rc != 0)
		return rc;

	offset += LBA_SIZE;
	rc = print_partition_info(fd, offset);
	if (rc != 0)
		return rc;

	close(fd);
	return 0;
}
