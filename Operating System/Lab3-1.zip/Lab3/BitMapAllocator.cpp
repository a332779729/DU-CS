/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include "BitMapAllocator.h"

using namespace std;

BitMapAllocator::BitMapAllocator(uint32_t sizeOfMemory)
{
    this->sizeOfFrames = sizeOfMemory;
    this->countOfUnusedFrames = sizeOfMemory;

    for (auto i = 0; i < 256; i++) {
        bitmap[i] = 0;
    }

    for (uint32_t i = 0; i < sizeOfFrames; i++) {
        bitmap[i] = 1;
    }

    for (auto i = 0; i < 4; i++) {
        processes[i] = vector<uint32_t>(0);
    }

    bitmap[0] = 0;
    countOfUnusedFrames -= 1;
}

BitMapAllocator::~BitMapAllocator()
{
}

BitMapAllocator::BitMapAllocator(const BitMapAllocator& other){ // copy constructor
    
}

BitMapAllocator::BitMapAllocator(BitMapAllocator&& other)noexcept { // move constructor
    
}

BitMapAllocator& BitMapAllocator::operator= (const BitMapAllocator& other){ // copy assignment
    //return *this = BitMapAllocator(other);
    //return nullptr;
}

BitMapAllocator& BitMapAllocator::operator= (BitMapAllocator&& other)noexcept{ // move assignment
    //std::swap(cstring, other.cstring);
    //return nullptr;
}

/**
 * GetFrames        Allocation
 * @param count     number of page frames
 * @param &page_frames     The method should push the addresses of
 * all the allocated page frames onto the back of the vector page_frames
 * specified as the second argument.
 * @return          it is boolean return, whether getting frames is successful
 */bool BitMapAllocator::GetFrames(uint32_t count, vector<uint32_t> &page_frames)
{
    if (count <= countOfUnusedFrames) {
        auto i = 0;
        for (; count > 0; i++) {
            if (bitmap[i] == 1) {
                bitmap[i] = 0;
                page_frames.push_back(i);
                countOfUnusedFrames--;
                count--;
            }
        }
        cout << " T " << hex << countOfUnusedFrames << endl;
        return true;
    } else {
        cout << " F " << hex << countOfUnusedFrames << endl;
        return false; 
    }
}

/**
 * FreeFrames              Deallocation
 *
 * @param count            number of page frames
 * @param &page_frames     The method should push the addresses of
 * all the allocated page frames onto the back of the vector page_frames
 * specified as the second argument.
 * @return                 it is boolean return whether freeing frames is successful
 */
bool BitMapAllocator::FreeFrames(uint32_t count, vector<uint32_t> &page_frames)
{
    if (page_frames.size() >= count) {
        uint32_t lastIndex = 0;
        for (uint32_t i = 0; i < count; i++) {
            lastIndex = page_frames.back();
            bitmap[lastIndex] = 1;
            page_frames.pop_back();
            countOfUnusedFrames += 1;
        }
        cout << " T " << hex << countOfUnusedFrames << endl;
        return true;
    } else {
        cout << " F " << hex << countOfUnusedFrames << endl;
        return false;
    }
}

/**
 * get_free_count()
 * @return         count Of Unused Frames
 */
uint32_t BitMapAllocator::get_free_count() const{
    return countOfUnusedFrames;
}

/**
 * get_bit_map_string() -getting bit map in string format
 *
 * @return         Bitmap in string format
 */
string BitMapAllocator::get_bit_map_string() const
{
    stringstream ss;
    ss <<" ";
    uint8_t memSubBitmap = 0;
    // We will construct a bitmap to show
    for (auto i = 0; i < 32; i++) {
        for (auto j = 0; j < 8; j++) {
            memSubBitmap  += (bitmap[i * 8 + j] * pow(2, j));
        }
        ss << hex << setw(2) << setfill('0') << +memSubBitmap;
        if(i != 31){
            ss << " ";
        }
        memSubBitmap = 0;
    }
    return ss.str();
}

vector<uint32_t> &BitMapAllocator::getPageFrames(uint32_t processId)
{
    return processes[processId];
}
