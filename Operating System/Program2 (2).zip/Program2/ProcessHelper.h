/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ProcessHelper.h
 * Author: cheng
 *
 * Created on May 23, 2019, 11:02 PM
 */
#ifndef __process_helper_h__
#define __process_helper_h__

#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <fstream>

#include "./MemorySubsystemS2019/MMU.h"

const uint32_t page_size = 1024;

class FrameAllocator {
    private:
        mem::MMU *mmu;
        uint32_t countOfAllPages;
        uint32_t countOfUnusedPages;
    public:
        FrameAllocator(uint32_t sizeOfMemory);
        bool get_frames(uint32_t count, std::vector<uint32_t> &pages);
        void set_byte(uint32_t phyAddress, uint8_t value);
        uint8_t get_byte(uint32_t phyAddress);
};

struct PageTableEntry {
    uint32_t virtualPageId;
    uint32_t physicalPageId;
    bool isWritable;

    PageTableEntry(uint32_t _virtualPageId,
            uint32_t _physicalPageId,
            boolt _isWriteable)
        : virtualPageId(_virtualPageId),
        physicalPageId(_physicalPageId),
        isWritable(_isWriteable)
    {}
};

class PageTableManager {
    private:
        std::vector<PageTableEntry *> pageTable;
    public:
        pageTableManager()
            :pageTable(std::vector<PageTableEntry *>(0))
        {}
        ~pageTableManager() {}
        void insert_entry(uint32_t vPageId, uint32_t pPageId,
                bool isWriteable);
        uint32_t vaddr_to_paddr(uint32_t vaddr);
        void setWritable(uint32_t vPageId, bool isWriteable);
};

class Process {
    private:
        uint32_t processId;
        PageTableManager *pageTableManager;
    public:
        Process();
        ~Process();
        void setWritable(uint32_t vPageId, bool isWriteable){
          pageTableManager->setWritable(vPageId, isWriteable);
        }
};

class ProcessHelper {
    private:
        FrameAllocator *frameAllocator;
        std::vector<Process *> processes;
        uint32_t nextProcessId;
    public:
        ProcessHelper();
        ~ProcessHelper();
        uint32_t new_process();
        int run_process(uint32_t processId, std::string filename);
        int operate_command(uint32_t processId, uint32_t opCode,
                vector<uint32_t> args);
};

#endif


