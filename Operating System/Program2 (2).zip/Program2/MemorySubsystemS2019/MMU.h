/* 
 * Interface to Virtual Memory (Memory Management Unit)
 * 
 * File:   MMU.h
 * Author: Mike Goss <mikegoss@cs.du.edu>
 */

#ifndef MEM_MMU_H
#define MEM_MMU_H

#include "Exceptions.h"
#include "PageTable.h"
#include "PSW.h"
#include "TLB.h"

#include <memory>

namespace mem {

class MMU {
public:
/**
   * Constructor (TLB enabled)
   * 
   * MMU is initialized with virtual memory disabled. 
   * Call load_kernel_psw0 to enable virtual memory.
   * 
   * @param frame_count_ number of page frames to allocate in physical memory
   * @param tlb_size_ number of entries in TLB (must be > 0)
   * @throws std::bad_alloc if insufficient memory
   */
  MMU(Addr frame_count_, size_t tlb_size);
  
  /**
   * Constructor (TLB disabled)
   * 
   * MMU is initialized with virtual memory disabled (PSW0 is 0). 
   * Call load_kernel_psw0 to enable virtual memory. No TLB is used with MMU.
   * 
   * @param frame_count_ number of page frames to allocate in physical memory
   * @throws std::bad_alloc if insufficient memory
   */
  MMU(Addr frame_count_);
  
  ~MMU() { }
  
  MMU(const MMU &other) = delete;  // no copy constructor
  MMU(MMU &&other) = delete;       // no move constructor
  MMU operator=(const MMU &other) = delete;  // no copy assign
  MMU operator=(MMU &&other) = delete;       // no move assign

  /**
   * get_frame_count - return number of page frames allocated
   * 
   * @return number of page frames in physical memory 
   */
  Addr get_frame_count() const { return frame_count; }
  
  /**
   * movb - get a single byte from the specified virtual address
   * 
   * @param dest - destination byte
   * @param vaddress - address of data in memory
   * @return true if success, false if operation aborted by fault handler
   */
  bool movb(void *dest, Addr vaddress);
  
  /**
   * movb - copy a range of bytes to caller buffer
   * 
   * @param dest where to copy to
   * @param address source virtual address
   * @param count number of bytes to copy
   * @return true if success, false if operation aborted by fault handler
   */
  bool movb(void *dest, Addr vaddress, Addr count);

  /**
   * movb - store a single byte to the specified virtual address
   * 
   * @param vaddress - address of data in memory
   * @param src - pointer to data to store at address
   * @return true if success, false if operation aborted by fault handler
   */
  bool movb(Addr vaddress, void *src);

  /**
   * movb - copy a range of bytes into physical memory
   * 
   * @param vaddress virtual address destination
   * @param count number of bytes to copy
   * @param src source buffer
   * @return true if success, false if operation aborted by fault handler
   */
  bool movb(Addr vaddress, void *src, Addr count);
  
  /**
   * load_kernel_psw0 - load kernel Processor Status Word 0
   * 
   * Replaces kernel PSW0 with the specified value. This function may only be
   * called once, and should put the MMU into virtual mode.  Bit VMode must be
   * set to 1, and bit UMode must be set to 0. 
   * 
   * @param new_psw0 new value for PSW0
   * @throws InvalidMMUOperationException if invalid PSW0
   */
  void load_kernel_psw0(PSW new_psw0);
  
  /**
   * load_user_psw0 - set the PSW0 value for user mode, and switch to user mode.
   * 
   * If the MMU is in physical memory mode according to the kernel PSW0,
   * this will throw an exception. Bits VMode and UMode must be set to 1. 
   * 
   * @param new_psw0 new value for PSW0
   * @throws InvalidMMUOperationException if invalid PSW0
   */
  void load_user_psw0(PSW new_psw0);
  
  /**
   * get_user_psw0 - get a copy of the current user mode PSW0 contents
   * 
   * @return psw0 contents
   */
  PSW get_user_psw0(void) const { return *psw0; }
  
  /**
   * get_user_psw1 -get a copy of the current user mode PSW1 contents
   * 
   * @return psw1 contents
   */
  uint8_t *get_user_psw1(void) { return psw1[1]; }
  
  /**
   * set_kernel_mode - switch the MMU to kernel mode, using the PSW0
   *   set by the load_kernel_psw0 function.
   * 
   * @return a copy of the PSW0 in use before the call to this function.
   */
  PSW set_kernel_mode(void);
  
  /**
   * get_kernel_psw0 - get a copy of the current kernel mode PSW0 contents
   * 
   * @param cur_psw0 location to store PSW0 contents
   */
  void get_kernel_psw0(PSW &cur_psw0) const { cur_psw0 = kernel_psw0; }
  
  /**
   * get_byte_count - return total number of bytes transferred so far 
   *   to/from physical memory.
   * 
   * @return count of bytes transferred.
   */
  uint64_t get_byte_count() const { return phys_mem.get_byte_count(); }
  
  /**
   * isTLBEnabled - query whether MMU has TLB enabled
   * 
   * @return true if TLB enabled, false otherwise
   */
  bool isTLBEnabled() const { return tlb.get() != nullptr; }
  
  /**
   * FlushTLB - flush the TLB (ignored if TLB disabled)
   */
  void FlushTLB() { if (tlb) tlb->Flush(); }
  
  /**
   * get_TLBStats - get TLB statistics
   * 
   * @param stats statistics from TLB
   * @throws InvalidMMUOperationException if TLB not enabled
   */
  void get_TLBStats(TLB::TLBStats &stats);

  /**
   * FaultHandler - abstract base class for fault handler
   * 
   * To define a fault handler, create a derived class, supplying the Run
   * function. You may also include any other private data or other functions.
   * 
   * When a fault occurs, the Run method will be called with a copy of the
   * user mode PSW0. The kernel mode PSW0 is set before calling the Run
   * method, and the user mode PSW0 is restored on exit. The PSW0 value and
   * execution mode (user or kernel) should not be changed while executing
   * the fault handler.
   */
   class FaultHandler {
   public:
     virtual bool Run(const PSW psw0) = 0;  // derived class must override
   protected:
     FaultHandler(){}; // protected - only a derived class object can be created
   };

  /**
   * SetPageFaultHandler - set the fault handler for page faults.
   *   The handler returns true to resume the operation which caused
   *   the page fault, false to abort the operation.
   * 
   * @param handler function called when page fault occurs
   */
  void SetPageFaultHandler(const std::shared_ptr<FaultHandler> &handler) {
    page_fault_handler = handler;
  }
  
  /**
   * SetWritePermissionFaultHandler - set the function to be called when a
   *   write permission fault occurs. The handler is called with the value
   *   of PSW0 at the time of the fault. The handler returns true to resume 
   *   the operation which caused the page fault, false to abort the operation. 
   * 
   * @param handler function called when page fault occurs
   */
  void SetWritePermissionFaultHandler(const std::shared_ptr<FaultHandler> &handler) {
    write_permission_fault_handler = handler;
  }
  
private:
  Addr frame_count;  // number of frames allocated in physical memory
  PhysicalMemory phys_mem;
  PSW kernel_psw0 ;   // kernel mode PSW0
  PSW user_psw0;      // user mode PSW0
  PSW *psw0;          // pointer to current PSW0 (kernel or user)
  uint8_t *psw1[2];   // pointer to next byte in partially-completed operation
                      // (index 0 for kernel mode, index 1 for user mode)
  
  // TLB (null if TLB disabled)
  std::unique_ptr<TLB> tlb;
  
  // Fault handler data
  bool fault_handler_active;   // true while fault handler is running
  std::shared_ptr<FaultHandler> page_fault_handler;
  std::shared_ptr<FaultHandler> write_permission_fault_handler;
  
  /**
   * InitMemoryOperation - setup memory operation in PSW0 and PSW1.
   * 
   * @param op - kPSW0_OpWrite or kPSW0_OpRead
   * @param vaddress virtual address
   * @param count number of bytes
   * @param user_buffer pointer to caller buffer (must be at least count bytes)
   */
  void InitMemoryOperation(PSW op, 
                           Addr vaddress, 
                           Addr count, 
                           uint8_t *user_buffer);
  
  /**
   * ToPhysical - convert virtual address to physical address.
   * 
   * If virtual mode is enabled, map a virtual address to a physical address. 
   * If the TLB is enabled and the page containing the virtual address is in 
   * the TLB, the page table is not consulted. Otherwise, the address is mapped
   * using the page table, and the mapping is cached in the TLB (if enabled).
   * 
   * If virtual mode is disabled, paddress is set to vaddress. The TLB is
   * unused and unchanged in this case.
   * 
   * @param vaddress virtual address to map
   * @param paddress returns corresponding physical address (undefined if not mapped)
   * @param write_op true if mapping for a write operation
   * @throws InvalidMMUOperationException if bad page table or other errors
   * @return true if success, false if operation aborted by fault handler
   */
  bool ToPhysical(Addr vaddress, Addr &paddress, bool write_op);
  
  /**
   * Execute - execute a (possibly partially complete) operation using the
   *           current PSW0 and PSW1 contents, which should contain the state of
   *           the operation.  Executing when no partially completed operation
   *            is pending will result in an InvalidMMUOperationException.
   * 
   * @return true if success, false if operation aborted by fault handler
   */
  bool Execute(void);
  
  /**
   * UpdatePSW0 - update field in PSW0
   * 
   * @param shift bit shift for field
   * @param mask mask for field
   * @param new_value new value to insert in field
   */
  void UpdatePSW0 (int shift, PSW mask, PSW new_value){
    *psw0 = (*psw0 & ~(mask << shift)) | ((new_value & mask) << shift);
  }

  /**
   * GetPSW0 - get field from PSW0
   * @param shift bit shift for field
   * @param mask mask for field
   * @return field value
   */
  PSW GetPSW0(int shift, PSW mask) const {
    return (*psw0 >> shift) & mask;
  }
};

}  // namespace mem

#endif /* MEM_MMU_H */

