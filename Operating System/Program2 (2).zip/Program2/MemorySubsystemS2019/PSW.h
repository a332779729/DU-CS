/* 
 * Processor Status Words (PSW) definitions
 * 
 * The Processor Status Words control the current state of the MMU interface.
 * They are 64-bit words which contains the bit fields described below,
 * controlling how the  processor interfaces with memory.  In an actual hardware 
 * implementation, the PSW contents would be loaded into hardware registers.
 * 
 * There are two PSW. PSW0 contains a number of fields as defined below.
 * PSW0 can be read or written by using MMU operations.
 * PSW1 (read-only) contains the user-buffer address of a partially completed
 * operation.
 *
 * File:   PSW.h
 * Author: Mike Goss <mikegoss@cs.du.edu>
 */

#ifndef MEM_PSW_H
#define MEM_PSW_H

#include "PhysicalMemory.h"
#include "PageTable.h"

#include <cstdint>

namespace mem {

typedef uint64_t PSW;              // define data type to store PSW value

// Define bit fields in PSW0. The shift values indicate the rightmost bit
// of the field. The mask can be used to extract the bits after right shifting
// by the shift value.

// Bit zero is virtual mode (0 = physical mode, 1 = virtual mode)
const int kPSW0_VModeShift = 0;
const PSW kPSW0_VModeMask = 0x1;

// Current user mode bit (0 = kernel, 1 = user)
const int kPSW0_UModeShift = 1;
const int kPSW0_UModeMask = 0x1;

// Partially-completed operation status
const int kPSW0_OpStateShift = 4;
const PSW kPSW0_OpStateMask = 0x3;
const PSW kPSW0_OpNone = 0x0;      // code for no operation
const PSW kPSW0_OpWrite = 0x1;     // code for write operation
const PSW kPSW0_OpRead = 0x2;      // code for read operation

// Next virtual address for partially-completed operation
const int kPSW0_NextAddrShift = 8;
const PSW kPSW0_NextAddrMask = 0x3FFFF;

// Remaining count for partially-completed operation
const int kPSW0_RemCountShift = 32;
const PSW kPSW0_RemCountMask = 0x3FFFF;

// Page frame number in main memory of page table
const int kPSW0_PageTableShift = 56;
const PSW kPSW0_PageTableMask = 0xFF;
}  // namespace mem

#endif /* MEM_PSW_H */

