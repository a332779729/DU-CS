/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "ProcessHelper.h"

using namespace std;

//???
FrameAllocator::FrameAllocator(uint32_t sizeOfMemory)
{
    mmu = new mem::MMU(sizeOfMemory);
    countOfAllPages = sizeOfMemory;
    uint8_t isAllocated = 0;
    for (uint32_t i = 0; i < sizeOfMemory; i++) {
        mmu->movb(i, &isAllocated);
    }

    isAllocated = 1;
    mmu->movb(sizeOfMemory - 1, &isAllocated);
    countOfUnusedPages = sizeOfMemory - 1;
}

/**
 * GetFrames        Allocation
 * @param count     number of page frames
 * @param &page_frames     The method should push the addresses of
 * all the allocated page frames onto the back of the vector page_frames
 * specified as the second argument.
 * @return          it is boolean return, whether getting frames is successful
 */
bool FrameAllocator::get_frames(uint32_t count,
        vector<uint32_t> &pages)
{
    uint8_t isAllocated = 0;
    if (count <= countOfUnusedPages) {
        uint32_t i = 0;
        while (count > 0) {
            mmu->movb(&isAllocated, i);
            if (isAllocated == 0) {
                isAllocated = 1;
                mmu->movb(i, &isAllocated);
                countOfUnusedPages -= 1;
                pages.push_back(i);
                count -= 1;
            }
            i++;
        }
        return true;
    } else {
        return false;
    }
}

/**
 * set_byte        Allocation
 * @param count     number of page frames
 * @param &page_frames     The method should push the addresses of
 * all the allocated page frames onto the back of the vector page_frames
 * specified as the second argument.
 * @return          it is boolean return, whether getting frames is successful
 */
void FrameAllocator::set_byte(uint32_t phyAddress, uint8_t value){
    mmu->movb(phyAddress, &value);
}

uint8_t FrameAllocator::get_byte(uint32_t phyAddress){
    uint8_t value = 0;
    mmu->movb(&value, phyAddress);
    return value;
}

void PageTableManager::insert_entry(uint32_t vPageId, uint32_t pPageId,
        bool isWriteable)
{
    auto entry = new PageTableEntry(vPageId, pPageId, isWriteable);
    pageTable.push_back(entry);
}

uint32_t PageTableManager::vaddr_to_paddr(uint32_t vaddr)
{
    uint32_t vPageId = vaddr / page_size;
    uint32_t vPageOffset = vaddr % page_size;
    for (auto entry : pageTable) {
        if (entry->virtualPageId == vPageId) {
            return entry->physicalPageId * page_size + vaddr;
        }
    }
    return !vaddr;
}

Process::Process(uint32_t _processId)
{
    processId = _processId;
    pageTableManager = new PageTableManager();

}

//constructor
ProcessHelper::ProcessHelper()
{
    frameAllocator = new FrameAllocator(64);
    processes = vector<Process *>(0);
    nextProcessId = 0;
}

//destructor
ProcessHelper::~ProcessHelper()
{
    file.close();
}


uint32_t ProcessHelper::new_process()
{
    uint32_t pid = nextProcessId;
    processes.push_back(new Process(pid));

    nextProcessId += 1;
    return pid;
}

/**
 * operate_command
 * @param processId   find the process id
 * @param opCode   operating code
 * @param args     saved argument
 * @return         no return
 */
int ProcessHelper::operate_command(uint32_t processId, uint32_t opCode,
        vector<uint32_t> args)
{
    switch (opCode) {
        case 0xF01:
            if (args.size() != 2) {
                cout << "Error: arguments are not enough or too much" << endl;
                return 1;
            }
            uint32_t count = args[0];
            uint32_t vaddr = args[1];
            uint32_t virtualPageId = vaddr / page_size;

            vector<uint32_t> pages;
            if (!frameAllocator->get_frames(count, pages)) {
                cout << "Error: not enough pages." << endl;
                return 2;
            }

            for (auto p : processes) {
                if (p->processId == processId) {
                    for (uint32_t i = 0; i < count; i++) {
                        p->pageTableManager->insert_entry(
                                virtualPageId + i, pages[i], true);
                    }
                }
            }

            break;

        // Compare to specified values
        case 0xCB1:
            if (args.size() < 2) {
                cout << "Error: arguments are not enough or too much" << endl;
                return 1;
            }
            uint32_t vaddr = args[0];
            uint8_t value = 0;
            for (auto p : processes) {
                if (p->processId == processId) {
                    uint32_t phyAddr = p->pageTableManager->vaddr_to_paddr(vaddr);
                    for (auto i = 0; i < args.size() - 1; i++) {
                        frameAllocator->get_byte(&value, phyAddr+i);
                        if(args[i+1] != value){
                            cout << "compare error at address " << hex << vaddr + i;
                            cout << ", expected " << hex << args[i+1];
                            cout << ", actual is " << hex << +value;
                            cout << endl;
                        }
                    }
                }
            }
            break;
        // Compare single value to memory range
        case 0xCBA:
            if (args.size() < 2) {
                cout << "Error: arguments are not enough or too much" << endl;
                return 1;
            }
            uint32_t count = args[0];
            uint32_t vaddr = args[1];
            uint32_t expectedValue = args[2];
            uint8_t value = 0;
            for (auto p : processes) {
                if (p->processId == processId) {
                    uint32_t phyAddr = p->pageTableManager->vaddr_to_paddr(vaddr);
                    for (i = 0; i < count; i++) {
                        frameAllocator->get_byte(&value, phyAddr + i);
                        if (value != expectedValue) {
                            cout << "compare error at address " << hex << vaddr + i;
                            cout << ", expected " << hex << +expectedValue;
                            cout << ", actual is " << hex << +value;
                            cout << endl;
                        }
                    }
                }
            }
            break;
        // Set bytes
        case 0x301:
            if (args.size() < 2) {
                cout << "Error: wrong arguments!" << endl;
            } else {
                uint32_t vaddr = args[0];
                uint32_t bytesCount = args.size() - 1;
                uint8_t value = 0;
                for (auto p : processes) {
                    if (p->processId == processId) {
                        uint32_t phyAddr = p->pageTableManager->vaddr_to_paddr(vaddr);
                        /*for (i = 0; i < count; i++) {
                            frameAllocator->set_byte(phyAddr + i, value);
                        }*/
                        for (int i = 0; i < bytesCount; i++) {
                            frameAllocator->set_byte(phyAddr + i, &args[i+1]);

                        }
                    }
                }
            }
            break;
        // Set multiple bytes to same value
        case 0x30A:
            if (args.size() != 3) {
                cout << "Error: wrong arguments!" << endl;
            } else {
                uint32_t count = args[0];
                uint32_t addr = args[1];
                uint32_t value = args[2];
                uint8_t value = 0;
                for (auto p : processes) {
                    if (p->processId == processId) {
                        uint32_t phyAddr = p->pageTableManager->vaddr_to_paddr(vaddr);

                        for (int i = 0; i < count; i++) {
                            frameAllocator->set_byte(phyAddr + i, &value);
                        }
                    }
                }

            }
            break;
        // Replicate range of bytes from source to destination
        case 0x31D:
            if (args.size() != 3) {
                cout << "Error: wrong arguments!" << endl;
            } else {
                uint32_t count = args[0];
                uint32_t dest_addr = args[1];
                uint32_t src_addr = args[2];
                uint8_t value = 0;
                for (auto p : processes) {
                    if (p->processId == processId) {
                        uint32_t dest_phyAddr = p->pageTableManager->vaddr_to_paddr(dest_addr);
                        uint32_t src_phyAddr = p->pageTableManager->vaddr_to_paddr(src_addr);

                        for (int i = 0; i < count; i++) {
                            frameAllocator->get_byte(&value, src_phyAddr + i);
                            frameAllocator->set_byte(dest_phyAddr + i, &value);
                        }
                    }
                }
            }
            break;
        // Output bytes
        case 0x4F0:
            if (args.size() != 2) {
                cout << "Error: wrong arguments!" << endl;
            } else {
                uint32_t count = args[0];
                uint32_t addr = args[1];
                uint8_t value = 0;
                for (auto p : processes) {
                    if (p->processId == processId) {
                        uint32_t phyAddr = p->pageTableManager->vaddr_to_paddr(addr);

                        for (int i = 0; i < count; i += 16) {
                            cout << hex << addr + i << ": ";
                            for (int j = 0; j < 16; j++) {
                                if (i + j < count) {
                                    frameAllocator->get_byte(&value, phyAddr + i + j);
                                    cout << hex << +value << ", ";
                                } else {
                                    break;
                                }
                            }
                            cout << endl;
                        }
                    }
                }
            }
            break;
        case 0xFF0:
            for (auto p : processes) {
                if (p->processId == processId) {
                  uint32_t const = args[0];
                  uint32_t vaddr = args[1];
                    uint32_t vpid = vaddr / 1024;
                    p->setWritable(vpid, 0);
                }
            }
            break;
        case 0xFF1:
            for (auto p : processes) {
                if (p->processId == processId) {
                  uint32_t const = args[0];
                  uint32_t vaddr = args[1];
                    uint32_t vpid = vaddr / 1024;
                    p->setWritable(vpid, 1);
                }
            }
            break;
        default:
            cout << "Error: Unsupported operation code!" << endl;
            break;
    }
    return 0;
}

void PageTableManager::setWritable(uint32_t vpid, bool w) {
      for (auto e : pageTable) {
      if (e->virtualPageId == vpid)
       e->isWritable = w;
          }
        }
      }

/**
 * run_process()
 * @return         return status of code
 */
int ProcessHelper::run_process(uint32_t processId, std::string filename)
{
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error: open() " << filename << endl;
        return 1;
    }

    string line, firstWord;
    uint32_t lineNum = 0;
    while (getline(file, line)) {
        lineNum += 1;
        istringstream lineStream(line);
        lineStream >> firstWord;

        cout << std::dec << lineNum << ":" << line << endl;
        if (firstWord == "*" || firstWord.size() == 0) {
            // Just print comment
        } else {
            uint32_t opCode;
            uint32_t arg;
            vector<uint32_t> args;
            istringstream opCodeStream(firstWord);

            opCodeStream >> hex >> opCode;
            while (lineStream >> hex >> arg) {
                args.push_back(arg);
            }

            operate_command(processId, opCode, args);
        }
        firstWord = "";
    }

    return 0;
}
