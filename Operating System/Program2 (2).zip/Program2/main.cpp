/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cheng
 *
 * Created on May 23, 2019, 9:38 PM
 */

#include "ProcessHelper.h"

using namespace std;

int main(int argc, char *argv[])
{
    if (argc != 2) {
        cout << "./main executeFile" << endl;
    }

    ProcessHelper *processHelper = new ProcessHelper();

    auto pid = processHelper->new_process();
    processHelper->run_process(pid, argv[1]);

    delete processHelper;
    return 0;
}


