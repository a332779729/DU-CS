/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PageTableHelper.h
 * Author: cheng
 *
 * Created on May 22, 2019, 9:09 PM
 */
// PageTableHelper.h
#include "MMU.h"
#include <iostream>
#include <vector>
#include <string>

using mem::MMU;
using mem::Addr;
using mem::PSW;

class PageTableHelper {
private:
    MMU vm;
    Addr kKernelPageTableBase;
    Addr kPageTableBase;
    Addr kVAddrStart;
    uint32_t freePagesCount;

    PSW kernelPsw0;
    PSW userPsw0;
    uint32_t userPageTableCount;
public:
    void build_kernel_page_table(Addr ptAddr);
    std::vector<Addr> get_free_pages(uint32_t count);
    PageTableHelper();
    void allocate_map_memory(uint32_t count, Addr vaddr);
    void compare_to_specified_values(Addr addr,
            std::vector<uint8_t> values);
    void compare_single_value(uint32_t count, Addr addr, uint8_t value);
    void set_bytes(Addr addr, std::vector<uint8_t> values);
    void set_bytes_same_value(uint32_t count, Addr addr, uint8_t value);
    void replicate_bytes(uint32_t count, Addr dest_addr, Addr src_addr);
    void output_bytes(uint32_t count, Addr addr);
    void change_write_permision(uint32_t count, Addr vaddr, bool w);
};

