/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// PageTableHelper.cpp
#include "PageTableHelper.h"
#include <MMU.h>

using namespace mem;

void PageTableHelper::build_kernel_page_table(Addr ptAddr)
{
    PageTable kernelPageTable;
    Addr numPages = vm.get_frame_count(); // 64

    for (Addr i = 0; i < numPages; ++i) {
        kernelPageTable.at(i) =
            (i << kPageSizeBits) | kPTE_PresentMask | kPTE_WritableMask;
    }

    vm.movb(ptAddr, &kernelPageTable, kPageTableSizeBytes);

    // Set memory bitmap
    uint8_t isAllocated = 0;
    for (int i = 0; i < 64; i++) {
        vm.movb(ptAddr + kPageSize + i, &isAllocated, 1);
    }
    isAllocated = 1;
    vm.movb(ptAddr + kPageSize + 62, &isAllocated, 1);
    vm.movb(ptAddr + kPageSize + 63, &isAllocated, 1);
    freePagesCount = 64 - 2;
}

/**
 * get_free_pages
 * @param count   find the count
 * @return         freePages
 */
std::vector<Addr> PageTableHelper::get_free_pages(uint32_t count)
{
    if (count > freePagesCount)
        return std::vector<Addr>(0);

    // Switch to kernel mode
    vm.set_kernel_mode();
    // Find free pages
    std::vector<Addr> freePages;
    uint8_t isAllocated = 1;
    for (int i = 0; i < 64; i++) {
        vm.movb(&isAllocated, kKernelPageTableBase + kPageSize + i);
        if (isAllocated == 0) {
            freePages.push_back(i);
            isAllocated = 0;
            vm.movb(kKernelPageTableBase + kPageSize + i,
                    &isAllocated);
            freePagesCount--;
            if (freePages.size() == count)
                break;
        }
    }
    vm.load_user_psw0(userPsw0);
    return freePages;
}

PageTableHelper::PageTableHelper()
    : vm(64),
    kKernelPageTableBase(62 * kPageSize),
    kPageTableBase(0),
    kVAddrStart((kPageTableEntries - 5) * kPageSize),
    kernelPsw0((1ULL << kPSW0_VModeShift)
            | (static_cast<uint64_t>(kKernelPageTableBase / kPageSize)
                << kPSW0_PageTableShift)),
    userPsw0((1ULL << kPSW0_VModeShift) | (1ULL << kPSW0_UModeShift)
            | (static_cast<uint64_t>(kPageTableBase / kPageSize)
                << kPSW0_PageTableShift)),
    userPageTableCount(0)
{
    // Set up kernel page table
    build_kernel_page_table(kKernelPageTableBase);
    PSW kernelPsw0 = (1ULL << kPSW0_VModeShift)
        | (static_cast<uint64_t>(kKernelPageTableBase / kPageSize)
                << kPSW0_PageTableShift);
    vm.load_kernel_psw0(kernelPsw0);
}

/**
 * allocate_map_memory
 * @param count   find the count
 * @param vaddr   find virsion address
 * @return         
 */
void PageTableHelper::allocate_map_memory(uint32_t count, Addr vaddr)
{
    auto freePages = get_free_pages(count);
    // Build user page table and write to memory
    Addr ptIndex = (vaddr >> kPageSizeBits) & kPageTableIndexMask;
    PageTable userPageTable;
    // Read page table from memory firstly
    vm.movb(&userPageTable, kPageTableBase, kPageTableSizeBytes);
    // Update page table
    for (Addr i = 0; i < count; i++) {
        userPageTable.at(ptIndex + i) =
            (freePages[i] * kPageSize) | kPTE_PresentMask
            | kPTE_WritableMask;
        userPageTableCount++;
    }
    // Write page table to memory
    vm.movb(kPageTableBase, &userPageTable, kPageTableSizeBytes);
    vm.load_user_psw0(userPsw0);
    vm.FlushTLB();
}

/**
 * compare_to_specified_values
 * @param addr   find the address
 * @param values   find values
 * @return        
 */
void PageTableHelper::compare_to_specified_values(Addr addr,
        std::vector<uint8_t> values)
{
    // Switch to user mode
    vm.load_user_psw0(userPsw0);
    vm.FlushTLB();
    for (uint32_t i = 0; i < values.size(); i++) {
        uint8_t data;
        vm.movb(&data, addr + i, 1);
        if (data != values[i]) {
            std::cout << "Not same as expected at: "
                << addr << ". Expected: " << values[i]
                << "In memory: " << data << std::endl;
        }
    }
}

void PageTableHelper::compare_single_value(uint32_t count, Addr addr, uint8_t value)
{
    vm.load_user_psw0(userPsw0);
    vm.FlushTLB();
    for (uint32_t i = 0; i < count; i++) {
        uint8_t data;
        vm.movb(&data, addr + i, 1);
        if (data != value) {
            std::cout << "Not same as expected at: "
                << addr << ". Expected: " << value
                << "In memory: " << data << std::endl;
        }
    }
}

/**
 * set_bytes
 * @param addr   find the address
 * @param values   find values
 * @return        
 */
void PageTableHelper::set_bytes(Addr addr, std::vector<uint8_t> values)
{
    vm.load_user_psw0(userPsw0);
    vm.FlushTLB();
    for (uint32_t i = 0; i < values.size(); i++) {
        vm.movb(addr + i, &values[i], 1);
    }
}

/**
 * set_bytes_same_value
 * @param count   find the count
 * @param addr   find the address
 * @param values   find values
 * @return        
 */
void PageTableHelper::set_bytes_same_value(uint32_t count, Addr addr, uint8_t value)
{
    vm.load_user_psw0(userPsw0);
    vm.FlushTLB();
    for (uint32_t i = 0; i < count; i++) {
        vm.movb(addr + i, &value, 1);
    }
}

/**
 * replicate_bytes
 * @param dest_addr   find the dest address
 * @param src_addr   find the src address
 * @param values   find values
 * @return        
 */
void PageTableHelper::replicate_bytes(uint32_t count, Addr dest_addr, Addr src_addr)
{
    vm.load_user_psw0(userPsw0);
    vm.FlushTLB();
    for (uint32_t i = 0; i < count; i++) {
        uint8_t data;
        vm.movb(&data, src_addr + i, 1);
        vm.movb(dest_addr + i, &data, 1);
    }
}

/**
 * output_bytes
 * @param count   find the count
 * @param addr   find the address
 * @return        
 */
void PageTableHelper::output_bytes(uint32_t count, Addr addr)
{
    vm.load_user_psw0(userPsw0);
    vm.FlushTLB();

    std::vector<uint8_t> result;

    for (uint32_t i = 0; i < count; i++) {
        uint8_t data;
        vm.movb(&data, addr + i, 1);
        result.push_back(data);
    }

    for (auto i = 0U; i < count; i += 16) {
        std::cout << std::hex << addr << ": ";
        for (auto j = 0U; j < 16 && i + j < count; j++) {
            std::cout << std::hex << result[i + j] << ",";
        }
        std::cout << std::endl;
    }
}

/**
 * change_write_permision
 * @param count   find the count
 * @param addr   find the address
 * @param w   write true or not
 * @return        
 */
void PageTableHelper::change_write_permision(uint32_t count, Addr vaddr, bool w)
{
    Addr ptIndex = (vaddr >> kPageSizeBits) & kPageTableIndexMask;
    PageTable userPageTable;
    // Read page table from memory firstly
    vm.movb(&userPageTable, kPageTableBase, kPageTableSizeBytes);
    // Update page table
    if (w == false) {
        for (Addr i = 0; i < count; i++) {
            userPageTable.at(ptIndex + i) &= ~kPTE_WritableMask;
            userPageTableCount++;
        }
    } else {
        for (Addr i = 0; i < count; i++) {
            userPageTable.at(ptIndex + i) |= kPTE_WritableMask;
            userPageTableCount++;
        }
    }
    // Write page table to memory
    vm.movb(kPageTableBase, &userPageTable, kPageTableSizeBytes);
    vm.load_user_psw0(userPsw0);
    vm.FlushTLB();
}
