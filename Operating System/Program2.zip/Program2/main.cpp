/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cheng shuhan
 *
 * Created on May 22, 2019, 9:08 PM
 */

// main.cpp

#include "PageTableHelper.h"
#include <MMU.h>
#include <sstream>
#include <fstream>

using namespace std;
using namespace mem;

PageTableHelper ptHelper;

/**
 * operate_command
 * @param processId   find the process id
 * @param opCode   operating code
 * @param args     saved argument
 * @return         no return
 */
void operate_command(uint32_t opCode, vector<uint32_t> args)
{
    switch (opCode) {
    case 0xF01:
        ptHelper.allocate_map_memory(args[0], args[1]);
        break;

    case 0xCB1: {
        vector<uint8_t> values;
        for (auto i = 1U; i < args.size(); i++)
            values.push_back(args[i]);
        ptHelper.compare_to_specified_values(args[0], values);
        break;
                }

    case 0xCBA:
        ptHelper.compare_single_value(args[0], args[1], args[2]);
        break;

    case 0x301: {
        vector<uint8_t> values;
        for (auto i = 1U; i < args.size(); i++)
            values.push_back(args[i]);
        ptHelper.set_bytes(args[0], values);
        break;
                }
    case 0x30A:
        ptHelper.set_bytes_same_value(args[0], args[1], args[2]);
        break;
    case 0x31D:
        ptHelper.replicate_bytes(args[0], args[1], args[2]);
        break;
    case 0x4F0:
        ptHelper.output_bytes(args[0], args[1]);
        break;
    case 0xFF0:
        ptHelper.change_write_permision(args[0], args[1], false);
        break;
    case 0xFF1:
        ptHelper.change_write_permision(args[0], args[1], true);
        break;
    default:
        break;
    }
}

void run_process(std::string filename)
{
    ifstream file(filename);
    if (!file.is_open()) {
       cout << "Error: open() " << filename << endl;
       return;
    }

    string line, firstWord;
    uint32_t lineNum = 0;
    while (getline(file, line)) {
        lineNum += 1;
        istringstream lineStream(line);
        lineStream >> firstWord;
        cout << std::dec << lineNum << ":" << line << endl;
        if (firstWord == "*" || firstWord.size() == 0) {
            // Just print comment
        } else {
            uint32_t opCode;
            uint32_t arg;
            vector<uint32_t> args;
            istringstream opCodeStream(firstWord);

            opCodeStream >> hex >> opCode;
            while (lineStream >> hex >> arg) {
                args.push_back(arg);
            }

            operate_command(opCode, args);
        }
        firstWord = "";
    }
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        cout << "Usage: ./main filename" << endl;
        return 1;
    }
    run_process(argv[1]);
}


