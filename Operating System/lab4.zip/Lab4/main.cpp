/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cheng shuhan
 *
 * Created on April 30, 2019, 10:09 PM
 */

#include <cstdlib>
#include "BitMapAllocator.h"

using namespace std;

int main(int argc, char **argv)
{
    ifstream fileStream;

    if (argc != 2) {
        cout << "Usage: ./main filePath" << endl;
        return 1;
    }

    fileStream.open(argv[1]);
    if (!fileStream.is_open()) {
        cout << "Error: open()" << endl;
        return 2;
    }

    string line;
    bool isFirstLine = true;
    uint32_t sizeOfMemory = 0;
    BitMapAllocator *bma = nullptr;
    while (getline(fileStream, line)) {
        // Print this line
        //cout << "+" << line << endl;
        stringstream lineStream(line);

        // Get size of memory
        if (isFirstLine) {
            lineStream >> hex >> sizeOfMemory;
            bma = new BitMapAllocator(sizeOfMemory);
            isFirstLine = false;
            cout << "+" << line << endl;
            continue;
        }
        
        // Operating B, G and F commands
        string command = "";
        uint32_t processId = 0;
        uint32_t framesCount = 0;
        lineStream >> command;
        if (command.size() >0){
            cout << "+" << line << endl;
        }
        if (command == "B") {
            cout << bma->get_bit_map_string() << endl;
        } else if (command == "G") {
            lineStream >> hex >> processId;
            lineStream >> hex >> framesCount;
            bma->GetFrames(framesCount, bma->getPageFrames(processId)); 
        } else if (command == "F") {
            lineStream >> hex >> processId;
            lineStream >> hex >> framesCount;
            bma->FreeFrames(framesCount, bma->getPageFrames(processId));
        }
    }
    //cout << endl;

    fileStream.close();
    return 0;
}
