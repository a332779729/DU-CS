/* 
 * Interface to Virtual Memory (Memory Management Unit)
 * 
 * File:   MMU.cpp
 * Author: Mike Goss <mikegoss@cs.du.edu>
 */

#include "MMU.h"

#include "Exceptions.h"

using mem::PSW;

namespace {
 
/**
 * DefaultHandler - throws exception if not replaced by user fault handler
 */
class DefaultHandler : public mem::MMU::FaultHandler {
public:
  DefaultHandler() {}
  virtual bool Run(const PSW psw0) {  // subclass must override
    throw mem::InvalidMMUOperationException("Missing FaultHandler");
  };
};

}  // namespace

namespace mem {

MMU::MMU(Addr frame_count_, size_t tlb_size)
: frame_count(frame_count_),
  phys_mem(frame_count_ * kPageSize),
  kernel_psw0(0),
  user_psw0(0),
  psw0(&kernel_psw0),
  tlb(std::make_unique<TLB>(tlb_size)),
  fault_handler_active(false),
  page_fault_handler(std::make_shared<DefaultHandler>()),
  write_permission_fault_handler(std::make_shared<DefaultHandler>())
{
  psw1[0] = nullptr;
  psw1[1] = nullptr;
}

MMU::MMU(Addr frame_count_) 
: frame_count(frame_count_), 
  phys_mem(frame_count_ * kPageSize),
  kernel_psw0(0),
  user_psw0(0),
  psw0(&kernel_psw0),
  tlb(nullptr),
  fault_handler_active(false),
  page_fault_handler(std::make_shared<DefaultHandler>()),
  write_permission_fault_handler(std::make_shared<DefaultHandler>())
{
  psw1[0] = nullptr;
  psw1[1] = nullptr;
}
  
void MMU::InitMemoryOperation(PSW op, 
                              Addr vaddress, 
                              Addr count, 
                              uint8_t* user_buffer) {
  UpdatePSW0(kPSW0_OpStateShift, kPSW0_OpStateMask, op);
  UpdatePSW0(kPSW0_NextAddrShift, kPSW0_NextAddrMask, vaddress);
  UpdatePSW0(kPSW0_RemCountShift, kPSW0_RemCountMask, count);
  size_t umode = GetPSW0(kPSW0_UModeShift, kPSW0_UModeMask);
  psw1[umode] = user_buffer;  // set psw1 for kernel or user mode
}

bool MMU::ToPhysical(Addr vaddress, Addr& paddress, bool write_op) {
  // If not in virtual memory mode, physical == virtual
  if (GetPSW0(kPSW0_VModeShift, kPSW0_VModeMask) == 0) {
    paddress = vaddress;
    return true;
  }
  
  // Get page table base
  Addr page_table_base = GetPSW0(kPSW0_PageTableShift, kPSW0_PageTableMask)
          << kPageSizeBits;
  
  // If virtual address exceeds address space size, fail
  if ((vaddress & ~kVirtAddrMask) != 0) {
    throw InvalidMMUOperationException(
            "Virtual address exceeds address space size");
  }
  
  // If address translation cached in TLB, use it
  PageTableEntry pt_entry = 0;  // page table entry contents
  Addr pt_entry_addr = 0xFFFFFFFF;  // page table entry address
  bool from_tlb = false;  // true if translation from TLB
  
  if (tlb) {
    pt_entry = tlb->Lookup(vaddress);
    // Use TLB entry if page present. If this is a write and the modified
    // bit is not set in the cache, force use of page table so that 
    // the modified bit will be updated in the page table.
    from_tlb = (pt_entry & kPTE_PresentMask) != 0
            && (!write_op || ((pt_entry & kPTE_ModifiedMask) != 0));
  }

  if (!from_tlb) {
    // Get entry from page table
    Addr pt_index = (vaddress >> kPageSizeBits) & kPageTableIndexMask;
    pt_entry_addr = page_table_base + pt_index * sizeof(PageTableEntry);
    phys_mem.movb32(&pt_entry, pt_entry_addr);
  }

  // Check for page present; if not, call page fault handler
  if ((pt_entry & kPTE_PresentMask) == 0) {
    PSW *saved_psw0 = psw0;
    psw0 = &kernel_psw0;  // switch to kernel mode
    if (tlb) tlb->Flush();
    fault_handler_active = true;
    bool retry = page_fault_handler->Run(*saved_psw0);
    fault_handler_active = false;

    // Restore saved state
    psw0 = saved_psw0;
    if (tlb) tlb->Flush();
    
    // If aborted
    if (!retry) {
      return false;
    }
    
    // Re-read page table entry and recheck state
    phys_mem.movb32(&pt_entry, pt_entry_addr);
    if ((pt_entry & kPTE_PresentMask) == 0) {  // if still missing
      throw InvalidMMUOperationException(
              "Page fault handler returned true but page not present");
    }
  }
  
  // If write operation and page not writable, call fault hander
  if (write_op && (pt_entry & kPTE_WritableMask) == 0) {
    PSW *saved_psw0 = psw0;
    psw0 = &kernel_psw0;  // switch to kernel mode
    fault_handler_active = true;
    bool retry = write_permission_fault_handler->Run(*saved_psw0);
    fault_handler_active = false;
    psw0 = saved_psw0;
    if (!retry) {
      return false;
    }
    if ((pt_entry & kPTE_WritableMask) == 0) { // if still protected
      throw InvalidMMUOperationException(
            "Write permission fault handler returned true but page still protected");
    }
  }
  
  // If address not from TLB, set accessed and (optionally) modified flags 
  // in 2nd level table, then update the TLB
  if (!from_tlb) {
    PageTableEntry new_pt_entry = pt_entry | kPTE_AccessedMask
            | (write_op ? kPTE_ModifiedMask : 0);

    // If changed, write back to page table
    if (new_pt_entry != pt_entry) {
      pt_entry = new_pt_entry;
      phys_mem.movb(pt_entry_addr, reinterpret_cast<uint8_t*>(&pt_entry),
                    sizeof(PageTableEntry));
    }
    
    // Update TLB
    if (tlb) {
      tlb->Cache(vaddress, pt_entry);
    }
  }
  
  // Page is mapped, return physical
  paddress = (pt_entry & kPTE_FrameMask) | (vaddress & kPageOffsetMask);
  
  return true;
}

bool MMU::Execute() {
  PSW op = GetPSW0(kPSW0_OpStateShift, kPSW0_OpStateMask);
  size_t umode = GetPSW0(kPSW0_UModeShift, kPSW0_UModeMask);  // user or kernel

  if (op == kPSW0_OpNone)
    return true;
  
  if (op != kPSW0_OpRead && op != kPSW0_OpWrite) {
    throw InvalidMMUOperationException("PSW0 operation is invalid");
  }
  
  while (GetPSW0(kPSW0_RemCountShift, kPSW0_RemCountMask) > 0) {
    // Check if next page is mapped and has correct write permission
    Addr next_paddress;
    Addr next_vaddress = GetPSW0(kPSW0_NextAddrShift, kPSW0_NextAddrMask);
    Addr remaining_count = GetPSW0(kPSW0_RemCountShift, kPSW0_RemCountMask);
    if (!ToPhysical(next_vaddress, next_paddress, op == kPSW0_OpWrite)) {
      return false;
    }
    
    // Determine remaining count within current page
    Addr count_in_page = std::min(remaining_count,
                                  kPageSize - (next_vaddress & kPageOffsetMask));
    
    // Transfer bytes
    if (op == kPSW0_OpRead) {
      phys_mem.movb(psw1[umode], next_paddress, count_in_page);
    } else {  // write
      phys_mem.movb(next_paddress, psw1[umode], count_in_page);
    }
    
    // Advance state of transfer
    UpdatePSW0(kPSW0_NextAddrShift, kPSW0_NextAddrMask,
                       next_vaddress + count_in_page);
    UpdatePSW0(kPSW0_RemCountShift, kPSW0_RemCountMask, 
                       remaining_count - count_in_page);
    psw1[umode] += count_in_page;
  }
  
  return true;
}

bool MMU::movb(void *dest, Addr vaddress) {
  InitMemoryOperation(kPSW0_OpRead, vaddress, 1, 
          reinterpret_cast<uint8_t*>(dest));
  return Execute();
}

bool MMU::movb(void *dest, Addr vaddress, Addr count) {
  InitMemoryOperation(kPSW0_OpRead, vaddress, count, 
          reinterpret_cast<uint8_t*>(dest));
  return Execute();
}

bool MMU::movb(Addr vaddress, void *src) {
  InitMemoryOperation(kPSW0_OpWrite, vaddress, 1, 
          reinterpret_cast<uint8_t*>(src));
  return Execute();  
}

bool MMU::movb(Addr vaddress, void *src, Addr count) {
  InitMemoryOperation(kPSW0_OpWrite, vaddress, count, 
          reinterpret_cast<uint8_t*>(src));
  return Execute();
}

void MMU::load_kernel_psw0(PSW new_psw0) {
  if (GetPSW0(kPSW0_VModeShift, kPSW0_VModeMask) != 0) {
    throw InvalidMMUOperationException(
            "load_kernel_psw0 called when already in virtual mode");
  } else if (((new_psw0 >> kPSW0_VModeShift) & kPSW0_VModeMask) == 0) {
    throw InvalidMMUOperationException(
            "load_kernel_psw0 called with VMode 0");
  } else if (((new_psw0 >> kPSW0_UModeShift) & kPSW0_UModeMask) == 1) {
      throw InvalidMMUOperationException(
          "load_kernel_psw0 called with UMode 1");
  }
  kernel_psw0 = new_psw0;
  psw0 = &kernel_psw0;
}

void MMU::load_user_psw0(PSW new_psw0) {
  if (fault_handler_active) {
    throw InvalidMMUOperationException("load_user_psw0 invalid in fault handler");
  } else if (((new_psw0 >> kPSW0_VModeShift) & kPSW0_VModeMask) == 0) {
    throw InvalidMMUOperationException(
            "load_user_psw0 called with VMode 0");
  } else if (((new_psw0 >> kPSW0_UModeShift) & kPSW0_UModeMask) == 0) {
      throw InvalidMMUOperationException(
          "load_user_psw0 called with UMode 0");
  }
  user_psw0 = new_psw0;
  psw0 = &user_psw0;
  UpdatePSW0(kPSW0_OpStateShift, kPSW0_OpStateMask, kPSW0_OpNone);
  UpdatePSW0(kPSW0_VModeShift, kPSW0_VModeMask, 1);
}

void MMU::get_TLBStats(TLB::TLBStats& stats) {
  if (tlb.get() != nullptr) {
    tlb->get_stats(stats);
  } else {
    throw InvalidMMUOperationException("TLB is not enabled, stats not available");
  }
}

PSW MMU::set_kernel_mode(void) {
  if (fault_handler_active) {
    throw InvalidMMUOperationException("set_kernel_mode invalid in fault handler");
  }
  PSW prev_psw0 = *psw0;
  psw0 = &kernel_psw0;
  return prev_psw0;
}

}  // namespace mem