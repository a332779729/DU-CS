/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BitMapAllocator.h
 * Author: cheng shuhan
 *
 * Created on April 30, 2019, 10:10 PM
 */

#ifndef BITMAPALLOCATOR_H
#define BITMAPALLOCATOR_H

#include "MemorySubsystemS2019/MMU.h"
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <fstream>
#include <iomanip>
#include <math.h>

using namespace std;

class BitMapAllocator {
    private:
        //uint8_t bitmap[256];
        mem::MMU *myMmu;
        uint32_t sizeOfFrames;
        uint32_t countOfUnusedFrames;
        // processes: used to record allocted frames' id
        vector<uint32_t> processes[4];
    public:
        BitMapAllocator(uint32_t sizeOfMemory);
        ~BitMapAllocator();
        BitMapAllocator(const BitMapAllocator& other) = delete;// copy constructor
        BitMapAllocator(BitMapAllocator&& other) = delete; // move constructor
        BitMapAllocator& operator= (const BitMapAllocator& other) = delete; // copy assignment
        BitMapAllocator& operator= (BitMapAllocator&& other) = delete; // move assignment
        bool GetFrames(uint32_t count, vector<uint32_t> &page_frames);
        bool FreeFrames(uint32_t count, vector<uint32_t> &page_frames);
        uint32_t get_free_count() const;
        string get_bit_map_string() const;
        vector<uint32_t> &getPageFrames(uint32_t processId);
};

#endif /* BITMAPALLOCATOR_H */
