/*
 * Trace - execute memory trace file.
 * 
 * COMP 3361 Spring 2019 Program 2 Sample Solution
 */

#ifndef TRACE_H
#define TRACE_H

#include "BitMapAllocator.h"
#include "ManagePageTable.h"
#include <MMU.h>

#include <fstream>
#include <string>
#include <vector>

class Trace {
public:
  /**
   * Constructor - open trace file, initialize processing
   * 
   * @param file_name_ source of trace commands
   */
  Trace(std::string file_name_, mem::MMU &memoory_, ManagePageTable &pt_manager_);
  
  /**
   * Destructor - close trace file, clean up processing
   */
  virtual ~Trace(void);

  // Other constructors, assignment: prevent copy and move
  Trace(const Trace &other) = delete;
  Trace(Trace &&other) = delete;
  Trace operator=(const Trace &other) = delete;
  Trace operator=(Trace &&other) = delete;
  
  /**
   * Run - read and process commands from trace file
   * 
   */
  void RunTrace(void);
  
private:
  // Trace file
  std::string file_name;
  std::fstream trace;
  long line_number;
  ManagePageTable &pt_manager;
  
  // Storage contents
  mem::MMU &memory;
  
  // PSW0 for MMU control
  mem::PSW user_psw0;
  
  // Fault handlers
  std::shared_ptr<mem::MMU::FaultHandler> page_fault_handler;
  std::shared_ptr<mem::MMU::FaultHandler> write_fault_handler;
  
  /**
   * InterpretCommand - interpret next trace file command.
   *   Aborts program if invalid trace file.
   * 
   * @param hexVals returns a vector of the command line values
   * @return true if command parsed, false if end of file
   */
  bool InterpretCommand(std::vector<uint32_t> &hexVals);
  
  /**
   * Command processors. Arguments are the same for each command.
   *   Form of the function is CmdX, where "X' is the command code.
   * @param hexVals command code and arguments
   */
  void CodeF01(const std::vector<uint32_t> &hexVals);  // allocate and map pages
  void CodeCB1(const std::vector<uint32_t> &hexVals);  // Compare to Specified Values
  void CodeCBA(const std::vector<uint32_t> &hexVals);  // Compare Single Value to Memory Range
  void Code301(const std::vector<uint32_t> &hexVals);  // Set Bytes
  void Code30A(const std::vector<uint32_t> &hexVals);  // Set Multiple Bytes to Same Value
  void Code31D(const std::vector<uint32_t> &hexVals);  // Replicate Range of Bytes From Source to Destination
  void Code4F0(const std::vector<uint32_t> &hexVals);  // Output Bytes
  void CodeFF0(const std::vector<uint32_t> &hexVals);  // Mark page(s) read-only
  void CodeFF1(const std::vector<uint32_t> &hexVals);  // Mark page(s) writable
};

#endif /* TRACE_H */

