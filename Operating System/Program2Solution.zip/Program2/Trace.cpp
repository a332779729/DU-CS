/*
 * Trace - execute memory trace file.
 * 
 * COMP 3361 Spring 2019 Program 2 Sample Solution
 *
 * Implementation of Trace class.
 */

#include "Trace.h"

#include <algorithm>
#include <cctype>
#include <iomanip>
#include <ios>
#include <iostream>
#include <sstream>

using std::cerr;
using std::cin;
using std::copy;
using std::cout;
using std::dec;
using std::getline;
using std::hex;
using std::istringstream;
using std::setfill;
using std::setw;
using std::string;
using std::vector;

using namespace mem;

namespace {

  // Define command code for comment or blank line
  const uint32_t kComment = 0xFFFFFFFF;
  
  // Define page fault handler
  class PageFaultHandler : public mem::MMU::FaultHandler {
  public:
    virtual bool Run(const PSW psw0) override {
      // Get fault type and address of fault
      uint32_t fault_type = 
              (psw0 >> mem::kPSW0_OpStateShift) & mem::kPSW0_OpStateMask;
      Addr vaddr =
              (psw0 >> mem::kPSW0_NextAddrShift) & mem::kPSW0_NextAddrMask;
      cout << ((fault_type == mem::kPSW0_OpRead) ? "Read " : "Write ")
              << "Page Fault at " << hex << setfill('0') << setw(8)
              << vaddr << "\n";
      return false;
    }
  };
  
  // Define write fault handler
  class WriteFaultHandler : public mem::MMU::FaultHandler {
  public:
    virtual bool Run(const PSW psw0) override {
      // Get address of fault
      Addr vaddr =
              (psw0 >> mem::kPSW0_NextAddrShift) & mem::kPSW0_NextAddrMask;
      cout << "Write Permission Fault at " << hex << setfill('0') << setw(8)
              << vaddr << "\n";
      return false;
    }
  };

}  // namespace

Trace::Trace(string file_name_, MMU &memory_, ManagePageTable &pt_manager_) 
: file_name(file_name_), line_number(0), pt_manager(pt_manager_), memory(memory_) {  
  // Open the trace file.  Abort program if can't open.
  trace.open(file_name, std::ios_base::in);
  if (!trace.is_open()) {
    cerr << "ERROR: failed to open trace file: " << file_name << "\n";
    exit(2);
  }
  
  // Set up user page table
  memory.set_kernel_mode();
  Addr pt_base = pt_manager.CreateProcessPageTable();
  user_psw0 = (static_cast<PSW>(pt_base) << (kPSW0_PageTableShift - kPageSizeBits))
          | (kPSW0_UModeMask << kPSW0_UModeShift) 
          | (kPSW0_VModeMask << kPSW0_VModeShift);
  
  // Create fault handlers
  page_fault_handler = std::make_shared<PageFaultHandler>();
  write_fault_handler = std::make_shared<WriteFaultHandler>();
}

Trace::~Trace() {
  trace.close();
}

void Trace::RunTrace(void) {
  // Switch to user PSW0
  memory.load_user_psw0(user_psw0);
  
  // Set fault handlers
  memory.SetPageFaultHandler(page_fault_handler);
  memory.SetWritePermissionFaultHandler(write_fault_handler);
  
  // Read and process commands
  string line; // text line read
  string cmd; // command from line
  vector<uint32_t> hexVals; // arguments from line

  // Select the command to execute
  while (InterpretCommand(hexVals)) {
    switch (hexVals[0]) {
      case 0xF01:
        CodeF01(hexVals); // allocate and map pages
        break;
      case 0xCB1:
        CodeCB1(hexVals); // Compare to Specified Values
        break;
      case 0xCBA:
        CodeCBA(hexVals); // Compare Single Value to Memory Range
        break;
      case 0x301:
        Code301(hexVals); // Set Bytes
        break;
      case 0x30A:
        Code30A(hexVals); // Set Multiple Bytes to Same Value
        break;
      case 0x31D:
        Code31D(hexVals); // Replicate Range of Bytes From Source to Destination
        break;
      case 0x4F0:
        Code4F0(hexVals); // Output Bytes
        break;
      case 0xFF0:
        CodeFF0(hexVals); // mark page(s) read-only
        break;
      case 0xFF1:
        CodeFF1(hexVals); // page(s) writable
        break;
      case kComment:
        break;
      default:
        cerr << "ERROR: invalid command\n";
        exit(2);
    }
  }
}

bool Trace::InterpretCommand(vector<uint32_t> &hexVals) {
  hexVals.clear();
  string textLine;
  
  // Read next textLine
  if (getline(trace, textLine)) {
    ++line_number;
    cout << dec << line_number << ":" << textLine << "\n";
    
    // No further processing if comment
    if (textLine.empty() || textLine[0] == '*') {
      hexVals.push_back(kComment);
      return true;
    }
    
    // Make a string stream from command line
    istringstream lineStream(textLine);
    
    // Read the hex values from the line
    uint32_t hVal;
    while (lineStream >> hex >> hVal) {
      hexVals.push_back(hVal);
    }
    
    // If no values read, set as comment
    if (hexVals.empty()) hexVals.push_back(kComment);
    
    return true;
  }
  
  // Check for eof or error
  if (trace.eof()) {
    return false;
  } else {
    cerr << "ERROR: getline failed on trace file: " << file_name 
            << " at line " << line_number << "\n";
    exit(2);
  }
}

void Trace::CodeF01(const vector<uint32_t> &hexVals) {
  if (hexVals.size() == 3) {
    memory.set_kernel_mode();
    pt_manager.MapProcessPages(user_psw0, hexVals[2], hexVals[1]);
    memory.load_user_psw0(user_psw0);
  } else {
    cerr << "ERROR: badly formatted command\n";
    exit(2);
  }
}

void Trace::CodeCB1(const vector<uint32_t> &hexVals) {
  // Compare to Specified Values
  Addr addr = hexVals.at(1);

  // Compare specified byte values
  uint8_t b;  // byte buffer
  for (int i = 2; i < hexVals.size(); ++i) {
    if (!memory.movb(&b, addr)) return;
    if(b != hexVals.at(i)) {
      cout << "compare error at address " << hex << setw(8) << setfill('0')
              << addr
              << ", expected " << setw(2) << hexVals.at(i)
              << ", actual is " << setw(2) << static_cast<uint32_t>(b) << "\n";
    }
    ++addr;
  }
}

void Trace::CodeCBA(const vector<Addr> &hexVals) {
  // Compare Single Value to Memory Range
  Addr count = hexVals.at(1);
  Addr addr = hexVals.at(2);
  uint32_t val = hexVals.at(3);

  // Compare specified byte values
  uint8_t b;  // byte buffer
  for (Addr i = 0; i < count; ++i) {
    if (!memory.movb(&b, addr+i)) return;
    if(b != val) {
      cout << "compare error at address " << hex << setw(8) << setfill('0')
              << addr+i
              << ", expected " << setw(2) << val
              << ", actual is " << setw(2) << static_cast<uint32_t>(b) << "\n";
    }
  }
}

void Trace::Code301(const vector<uint32_t> &hexVals) {
  // Store multiple bytes starting at specified address
  Addr addr = hexVals.at(1);
  uint8_t b;
  for (int i = 2; i < hexVals.size(); ++i) {
    b = hexVals.at(i);
    if (!memory.movb(addr++, &b)) return;
  }
}

void Trace::Code31D(const vector<uint32_t> &hexVals) {
  // Replicate Range of Bytes From Source to Destination
  Addr dst = hexVals.at(2);
  Addr src = hexVals.at(3);
  Addr count = hexVals.at(1);
  uint8_t b;  // buffer
  while (count-- > 0) {
    if (!memory.movb(&b, src++)) return;
    if (!memory.movb(dst++, &b)) return;
  }
}

void Trace::Code30A(const vector<uint32_t> &hexVals) {
  // Set Multiple Bytes to Same Value
  uint8_t value = hexVals.at(3);
  Addr count = hexVals.at(1);
  Addr addr = hexVals.at(2);
  for (int i = 0; i < count; ++i) {
    if (!memory.movb(addr++, &value)) return;
  }
}

void Trace::Code4F0(const vector<uint32_t> &hexVals) {
  // Output bytes
  Addr addr = hexVals.at(2);
  Addr count = hexVals.at(1);

  // Output the specified number of bytes starting at the address
  uint8_t b;
  for (int i = 0; i < count; ++i) {
    if ((i % 16) == 0) { // Write new line with address every 16 bytes
      if (i > 0) cout << "\n";  // not before first line
      cout << hex << setw(8) << setfill('0') << addr << ": ";
    } else {
      cout << ",";
    }
    if (!memory.movb(&b, addr++)) return;
    cout << setfill('0') << setw(2) << static_cast<uint32_t> (b);
  }
  cout << "\n";
}

void Trace::CodeFF0(const std::vector<uint32_t>& hexVals) {
  Addr addr = hexVals.at(2);
  Addr count = hexVals.at(1);
  PSW psw0 = memory.set_kernel_mode();
  pt_manager.SetPageWritePermission(psw0, addr, count, 0);
  memory.load_user_psw0(psw0);
}

void Trace::CodeFF1(const std::vector<uint32_t>& hexVals) {
  Addr addr = hexVals.at(2);
  Addr count = hexVals.at(1);
  PSW psw0 = memory.set_kernel_mode();
  pt_manager.SetPageWritePermission(psw0, addr, count, 1);
  memory.load_user_psw0(psw0);
}
