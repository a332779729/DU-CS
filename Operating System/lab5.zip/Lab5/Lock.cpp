/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Lock.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct Process{
  uint32_t processNeed, processOwn;
  string processName;

  /**
   * constructor
   * 
   * @param processName   the name of process name
   * @param processOwn    how many thrand its own
   * @param processNeed    how many thrand its need
   * @return         no return
   */
  Process(string processName, uint32_t processOwn, uint32_t processNeed){
    this->processName=processName;
    this->processNeed=processNeed;
    this->processOwn=processOwn;
  }
};

/**
   * Lock::Lock
   * @param filename   file name
   * @return         no return
   */
Lock::Lock(std::string filename) {
  this->filename = filename;
}
void Lock::run() {
  ifstream file(filename);
  if (!file.is_open()) {
     cout << "Error: open() " << filename << endl;
     exit(-1);
  }

  vector<Process *> myProcesses;
  string line;
  bool isFirstLine = true;
  uint32_t countOfLastResource = 0;
  while (getline(file, line)) {
      istringstream lineStream(line);
      if( isFirstLine){
        lineStream >> dec >> countOfLastResource;
        isFirstLine = false;
        continue;
      }

      string processName;
      uint32_t processNeed, processOwn;
      lineStream  >> processName;
      lineStream  >> dec >> processOwn;
      lineStream  >> dec >> processNeed;

      // cout << processName << " " << processOwn << " " << processNeed << endl;
      myProcesses.push_back(new Process(processName, processOwn, processNeed));

  }

  //cout<<countOfLastResource<<endl;
  cout<< filename <<":";

  for(int i=0; i < myProcesses.size(); ){
    auto p = myProcesses[i];
    if(p->processNeed == 0){
      i++;
      continue;
    }

    uint32_t needMore = p->processNeed - p->processOwn;
    //cout<<countOfLastResource <<" "<< needMore<<endl;

    if(needMore <= countOfLastResource){
      p->processNeed = 0;
      countOfLastResource += p->processOwn;
      i = 0;
      cout<< " " << p->processName;
      continue;
    }
    i++;
  }

  uint32_t sum=0;
  for(auto p : myProcesses){
    sum += p->processNeed;
  }
  if(sum == 0){
    cout << " (Safe)"<< endl;
  }else{
    cout << " (Unsafe)" << endl;
  }
}
