/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lock.h
 * Author: cheng
 *
 * Created on May 26, 2019, 10:16 PM
 */

#include <string>

#ifndef __lock_h__
#define __lock_h__

class Lock {
public:
  Lock(std::string filename);
  void run();
private:
  std::string filename;
};

#endif


